package system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Basket {
	String jdbc_driver ="com.mysql.cj.jdbc.Driver";
	String dburl ="jdbc:mysql://localhost:3306/yumyum?serverTimezone=UTC";
	String dbUser ="root";		String dbpasswd ="admin";
	
	public int insertBasket(String nickname, String productNum, String count, String price) {
		int complete=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			complete=st.executeUpdate("insert into basket (nickname,buyNum,buyCount,price) values('"+nickname+"','"+productNum+"','"+count+"','"+price+"');");
		}catch(Exception e) {
			
		}
		
		return complete;
		
	}
	
}
