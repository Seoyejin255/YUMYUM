package system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import beans.UserInfo;

public class User {
	
	UserInfo user = new UserInfo();
	
	String jdbc_driver ="com.mysql.cj.jdbc.Driver";
	String dburl ="jdbc:mysql://localhost:3306/yumyum?serverTimezone=UTC";
	String dbUser ="root";		String dbpasswd ="admin";
	
	public int logPro(String id , String pw){//로그인 처리.
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select count(*) from user where id='"+id+"'&&pw='"+pw+"'");
			rs.next();
			count=rs.getInt("count(*)");
		}catch(Exception e) {
		}
		return count;
	}
	
	public String inputInfo(String id) {
		String nickname="";
		try {
		Class.forName(jdbc_driver);
		Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("select * from user where id='"+id+"'");
		rs.next();
		nickname=rs.getString("nickname");
		int power=rs.getInt("power");
		int point=rs.getInt("point");
		String phoneNumber=rs.getString("phoneNumber");
		String address=rs.getString("address");
		
		user.setAddress(address);
		user.setId(id);
		user.setNickname(nickname);
		user.setPhoneNumber(phoneNumber);
		user.setPoint(point);
		user.setPower(power);

		}catch(Exception e) {
		}
		return nickname;
	}
	public String powerCheck(String nickname) {
		String count="";
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from user where nickname='"+nickname+"'");
			rs.next();
			count=rs.getString("power");
		}catch(Exception e) {
		}
		return count;
	}
	
	
}
