package system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Shop {
	String jdbc_driver ="com.mysql.cj.jdbc.Driver";
	String dburl ="jdbc:mysql://localhost:3306/yumyum?serverTimezone=UTC";
	String dbUser ="root";		String dbpasswd ="admin";
	
	public int insertProduct(String title, String price, String stock,String titleImg,String content, String type) {
		int count=0;
		try {
			String content2="../shopFile/"+content;
			String titleImg2="../shopFile/"+titleImg;
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			count=st.executeUpdate("insert into shop (title,price,maxNum,content,titleImg,type) values('"
					+title+"',"
					+price+","
					+stock+",'"
					+titleImg2+"','"
					+content2+"','"
					+type+"')");
		}catch(Exception e) {
		}
		return count;
	}
	
}
