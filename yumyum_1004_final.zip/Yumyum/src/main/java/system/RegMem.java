package system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class RegMem {
	String jdbc_driver ="com.mysql.cj.jdbc.Driver";
	String dburl ="jdbc:mysql://localhost:3306/yumyum?serverTimezone=UTC";
	String dbUser ="root";		String dbpasswd ="admin";
	
	public int idCheck(String id) {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select count(*) from user where id='"+id+"'");
			rs.next();
			count=rs.getInt("count(*)");
		}catch(Exception e) {
		}
		return count;
	}
	
	public int nickCheck(String nickname) {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select count(*) from user where nickname='"+nickname+"'");
			rs.next();
			count=rs.getInt("count(*)");
		}catch(Exception e) {
		}
		return count;
	}
	public int pwCheck(String pw,String rpw) {
		int count=0;
		if(pw.equals(rpw)) {
			count=0;
		}else{
			count=1;
		}
		
		return count;
	}
	
	public int inputMem(String id, String pw, String nickname,String tel,String address,String nickname1) {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			count=st.executeUpdate("insert into user (id,pw,nickname,phoneNumber,address) values('"
			+id+"','"
			+pw+"','"
			+nickname1+"','"
			+tel+"','"
			+address+"')");
		}catch(Exception e) {
			
		}
		return count;
	}
	
}
