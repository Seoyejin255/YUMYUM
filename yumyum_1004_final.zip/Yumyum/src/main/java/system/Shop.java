package system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import beans.ProductInfo;

public class Shop {
	String jdbc_driver ="com.mysql.cj.jdbc.Driver";
	String dburl ="jdbc:mysql://localhost:3306/yumyum?serverTimezone=UTC";
	String dbUser ="root";		String dbpasswd ="admin";
	ProductInfo pi = new ProductInfo();
	
	public int insertProduct(String title, String price, String stock,String titleImg,String content, String type,String comment) {
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			count=st.executeUpdate("insert into shop (title,price,maxNum,content,titleImg,type,comment) values('"
					+title+"',"
					+price+","
					+stock+",'"
					+titleImg+"','"
					+content+"','"
					+type+"','"
					+comment+"')");
		}catch(Exception e) {
		}
		return count;
	}
	
	public ProductInfo ingredientInfo(String num){
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from shop where num="+num);
			rs.next();
			String title = rs.getString("title");
			String price = rs.getString("price");
			String maxNum = rs.getString("maxNum");
			String content = rs.getString("content");
			String titleImg = rs.getString("titleImg");
			String comment = rs.getString("comment");
			String type= rs.getString("type");
			pi.setComment(comment);
			pi.setContent(content);
			pi.setMaxNum(maxNum);
			pi.setNum(num);
			pi.setPrice(price);
			pi.setTitleImg(titleImg);
			pi.setTitle(title);
			pi.setType(type);
		}catch(Exception e) {
			
		}
		return pi;
	}
	
	public int purchaseProduct(String buyNum, String buyCount, String totalPrice,String nickname,String address, String tel) {
		//total 만 int임.
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			
			count=st.executeUpdate("insert into purchase (buyNum,buyCount,totalPrice,nickname,date,address,tel) values('"+buyNum+"','"+buyCount+"','"+totalPrice+"','"+nickname+"',now(),'"+address+"','"+tel+"');");

		}catch(Exception e) {
			
		}
		return count;
	}
	public int minusProduct(String buyNum,String productNum) {
		//total 만 int임.
		int count=0;
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			Statement st = conn.createStatement();
			st.executeUpdate("update shop set maxNum=maxNum-"+buyNum+" where num="+productNum);
		}catch(Exception e) {
			
		}
		return count;
	}
	
	
}
