
function add(price){
	var display = document.getElementById('display');
	var inputValue = parseInt(display.value);//1,2,3 올려주는 변수
	var result = eval(inputValue+1);
	var total = result *price;
	document.getElementById('display').value=result;
	document.getElementById('stotalPrice1').value=total;
	document.getElementById('stotalPrice2').value=total;
	document.getElementById('stotalPrice3').value=total;
}
function minus(num,price){
	var display = document.getElementById('display');
	var inputValue = parseInt(display.value);//3,2,1.. 내려주는 변수
	var num = num;
	var total;
	if(inputValue<=1){
		alert('한개 이하로는 구매 할 수 없습니다.');
		document.getElementById('display').value=inputValue;
		total = inputValue*price;
		document.getElementById('stotalPrice1').value=total;
		document.getElementById('stotalPrice2').value=total;
		location.href='showIngredient.jsp?num='+num;
	}else{
	var result = eval(inputValue-1);
	total = result*price;
	document.getElementById('stotalPrice1').value=total;
	document.getElementById('stotalPrice2').value=total;
	document.getElementById('display').value=result;
	}
}