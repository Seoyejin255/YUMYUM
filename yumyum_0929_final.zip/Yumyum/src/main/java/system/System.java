package system;

import java.io.PrintWriter;

public class System {
}
